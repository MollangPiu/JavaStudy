package campus.design.factory.test;

public interface Fectory {
    Product createProduct(String name);
}
