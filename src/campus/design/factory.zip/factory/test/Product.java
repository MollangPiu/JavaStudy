package campus.design.factory.test;

public interface Product {
    void use();
}
