package campus.design.factory.Logger;

interface Logger {
    //message 출력
    void log(String message);
}
