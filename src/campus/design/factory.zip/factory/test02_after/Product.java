package campus.design.factory.test02_after;

public interface Product {

    //Product 사용
    void use();
}
