package campus.design.factory.test03;

public interface Factory {
    Product create(String name);
}
