package campus.design.factory.test03;

public interface Product {

    void use();
}
