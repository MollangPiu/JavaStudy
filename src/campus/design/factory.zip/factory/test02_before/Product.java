package campus.design.factory.test02_before;

public interface Product {

    //Card 사용
    void use();
}
